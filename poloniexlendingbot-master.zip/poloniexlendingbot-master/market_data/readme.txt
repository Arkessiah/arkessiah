This folder holds market data for any coin lending markets you have chosen to record and analyse.
The bot automatically removes lines that are older than the setting for maximum age.

Try not to delete this data.
To build the .html docs for your own viewing:

1) Install python sphinx.
2) Do 'make html' in this directory.
3) Wait a few seconds.
4) The made html files will be under /build_/html/

.. Poloniexlendingbot documentation master file, created by
   sphinx-quickstart on Tue Oct 11 16:56:46 2016.

Welcome to Poloniexlendingbot's documentation!
==============================================

Poloniexlendingbot is an open-source program for automated lending on the Poloniex cryptocurrency exchange.

Contents:

.. toctree::
   :numbered:
   :maxdepth: 2

   installation
   configuration
   contributing


